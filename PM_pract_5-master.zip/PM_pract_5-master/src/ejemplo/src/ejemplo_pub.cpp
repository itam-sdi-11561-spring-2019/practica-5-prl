#include <ros/ros.h>

#include <iostream>
#include <std_msgs/Int32.h>

#include <std_msgs/String.h>

using namespace std;

#define RATE_HZ 2

string cad="";

void get_msg(const std_msgs::String& msg) {
	cad= msg.data;
	ROS_INFO_STREAM(cad);
}


int main(int argc, char **argv)
{
	ros::init(argc,argv,"ejemplo_pub_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("ejemplo_pub_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());
	
	ros::Subscriber sub_vel = nh.subscribe("/msg_ejemplo2", 1000, &get_msg);
	
	ros::Publisher pub = nh.advertise<std_msgs::Int32> ("/msg_ejemplo", 1);

	std_msgs::Int32 msg;
	int num; 
	
	ros::Rate rate(RATE_HZ);
		
	while (ros::ok())

	{	
		msg.data = num;
		pub.publish(msg);
		ros::spinOnce();
		// ros::spin();
		rate.sleep();
		cout << "Introduce un numero entero:" << endl;
		cin >> num;

		
		
	}

    return 0;
}
