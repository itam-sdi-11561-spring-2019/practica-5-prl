#include <ros/ros.h>

#include <iostream>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Twist.h>

using namespace std;

int main(int argc, char **argv)
{
	ros::init(argc,argv,"tortuga_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("tortuga_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Publisher pub = nh.advertise<geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);

	geometry_msgs::Twist move;
	int num;

	while (ros::ok())
	{
		cout << "Introduce una dirección:" << endl;
		cin >> num;

		switch(num) {
			case 2:
				move.linear.x = -1;
				move.angular.z = 0;
				break;
			case 4:
				move.angular.z = -3.1416/2;
				break;
			case 6:
				move.angular.z = 3.1416/2;
				break;
			case 8:
				move.angular.z = 0;
				move.linear.x = 1;
				break;
			default:
				break;
		}

		move.linear.y = 0;
		move.linear.z = 0;
		move.angular.x = 0;
		move.angular.y = 0;

		pub.publish(move);
	
	}

    return 0;
}
